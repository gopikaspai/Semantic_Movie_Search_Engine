
Team 6 : 
Drishty Kapoor
Gopika Sreedhara Pai
Shashidhar Reddy Vanteru
Manikanta Chintakunta


Link for the video in google drive: 

https://drive.google.com/open?id=1tCy89DtmNBMJW0G7trmVEYHkg93bnLwt