package com.example.Semantic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemanticApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemanticApplication.class, args);
	}
}
